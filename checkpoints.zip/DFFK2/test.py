

from utils.utils import extract_state_dict


if __name__ == "__main__":
    extract_state_dict()